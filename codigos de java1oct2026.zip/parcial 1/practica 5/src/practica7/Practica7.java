/*programa que imprime palabras a color
*diseñado: ERNESTO KALEB GASPAR LOPEZ


 */
package practica7;

public class Practica7 {

    public static void main(String[] args) {
      String rojo = "\033[31m";
      String verde = "\033[32m";
      String naranja = "\033[33m";
      String azul = "\033[34m";
      String morado = "\033[35m";
      String blanco = "\033[37m";
      
      System.out.println(naranja + "mandarina" + verde + " hierba");
      System.out.println("===================================================");
      System.out.println(naranja + " saltamontes" + rojo + " tomate");
      System.out.println("===================================================");
      System.out.println(blanco + " sábanas" + azul + " cielo");
      System.out.println("===================================================");
      System.out.println(morado + " nazareno" + azul + " mar");
      System.out.println("===================================================");
    }
    
}
